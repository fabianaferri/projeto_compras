
function calcularTotal(ferramentas, comprar) {
  let total = 0; 
  let ferramentasDesejadas = []; 

  for (let i = 0; i < ferramentas.length; i++) {
      const ferramenta = ferramentas[i];

      for (let i = 0; i < comprar.length; i++) {
          if (ferramenta.nome === comprar[i]) {
              total += ferramenta.preco;
              ferramentasDesejadas.push(ferramenta.nome);
          }
      }
  }
  if (ferramentas.length === 0 || comprar.length === 0) {
    throw new Error("Ambas as listas precisam ter ao menos um item.");
}

  if (ferramentasDesejadas.length === 0) {
      throw new Error("Nenhuma ferramenta desejada encontrada.");
  }

  return `O valor a pagar pelas ferramentas (${ferramentasDesejadas.join(', ')}) é R$ ${total.toFixed(2)}`;
}


module.exports = {
  calcularTotal
};